// src/App.tsx
import AppRouter from "@/router";

export default function App() {
  return <AppRouter />;
}
