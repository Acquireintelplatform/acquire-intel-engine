export type PortalSource =
  | "EGI"
  | "CoStar"
  | "Realla"
  | "Rightmove"
  | "NovaLoca"
  | "Custom"
  | string;
